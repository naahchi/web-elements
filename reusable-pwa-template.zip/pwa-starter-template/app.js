// PWA starter: registers a service worker for this project folder only.
(async () => {
  const status = document.getElementById("pwa-status");

  if (!("serviceWorker" in navigator)) {
    if (status) status.textContent = "Service workers are not supported in this browser.";
    return;
  }

  try {
    // Relative path keeps the worker inside this project's folder on GitHub Pages.
    await navigator.serviceWorker.register("./sw.js", { scope: "./" });
    if (status) status.textContent = "PWA service worker registered.";
  } catch (error) {
    console.error("Service worker registration failed:", error);
    if (status) status.textContent = "Service worker registration failed. Check the browser console.";
  }
})();
