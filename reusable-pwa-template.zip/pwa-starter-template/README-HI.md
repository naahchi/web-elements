# Reusable PWA Template (GitHub Pages)

यह टेम्पलेट किसी भी static HTML/CSS/JS प्रोजेक्ट को PWA बनाने के लिए है। इसे हर प्रोजेक्ट के **अपने अलग folder** में रखें।

## 1. फोल्डर में कॉपी करें

उदाहरण:

```text
my-repository/
├── project-one/
│   ├── index.html
│   ├── manifest.webmanifest
│   ├── app.js
│   ├── sw.js
│   ├── style.css
│   └── icons/
└── project-two/
    └── ...
```

हर PWA का `manifest.webmanifest`, `sw.js` और icons अलग रखें।

## 2. ऐप का नाम और विवरण बदलें

`manifest.webmanifest` खोलकर ये fields बदलें:

- `name`: मोबाइल पर ऐप का पूरा नाम
- `short_name`: मोबाइल launcher के लिए छोटा नाम
- `description`: ऐप का विवरण
- `theme_color`: browser/app theme color
- `background_color`: splash/background color

## 3. Path / URL सेट करना

इस टेम्पलेट में `id`, `start_url` और `scope` डिफ़ॉल्ट रूप से `./` हैं। इसका अर्थ है कि PWA अपने मौजूदा project folder तक सीमित रहेगा।

उदाहरण URL:

`https://USERNAME.github.io/REPOSITORY/project-one/`

यदि टेम्पलेट `project-one/` के अंदर है, तो सामान्यतः `./` को बदलने की जरूरत नहीं है। यह GitHub Pages के repository subpath सहित सही relative path resolve करता है।

**महत्वपूर्ण:** `start_url` और `scope` को `/project-one/` जैसे root-relative path में न बदलें, जब तक आपको अपने पूरे domain के path structure की स्पष्ट जानकारी न हो।

## 4. App icon बदलें

`icons/` में अपनी PNG फाइलें रखें और उनके नाम ये रखें:

- `icon-192.png` — 192 × 192 pixels
- `icon-512.png` — 512 × 512 pixels

दोनों square PNG हों। यदि अलग filenames रखना चाहते हैं, तो `manifest.webmanifest` में दोनों `src` भी बदलें। Transparent icon इस्तेमाल करने पर Android पर उसका रूप अलग दिख सकता है; सामान्य `purpose: "any"` icon के लिए साफ background वाला PNG रखें।

`icons/icon-source.svg` एक editable sample source है; इसे PNG में export करके ऊपर की दोनों फाइलों के रूप में रखें।

## 5. अपने प्रोजेक्ट की फाइलें जोड़ें

यह starter `index.html`, `style.css` और `app.js` देता है। अपना मौजूदा प्रोजेक्ट इस्तेमाल कर रहे हैं तो:
- अपना वास्तविक `index.html` रखें।
- उसमें `<link rel="manifest" href="./manifest.webmanifest">` जोड़ें।
- `app.js` का service-worker registration code अपने JS में जोड़ें, या script को शामिल करें।
- `sw.js` की `APP_SHELL` सूची में अपनी जरूरी local CSS/JS/image files जोड़ें।

ध्यान दें: `APP_SHELL` में ऐसी फाइलें ही रखें जो वास्तव में मौजूद हों, वरना install event में cache भरने का काम fail हो सकता है।

## 6. Cache update कैसे करें

जब आप ऐसा update publish करें जिसे पुराने cache से बदलना जरूरी हो, `sw.js` में:

```js
const CACHE_VERSION = "v1";
```

को `v2`, फिर `v3` करें। इससे पुराने cache को हटाकर नया cache बनेगा।

## 7. Install checklist

1. GitHub Pages पर HTTPS URL खोलें।
2. `manifest.webmanifest` URL सीधे खोलकर देखें कि JSON load हो रहा है।
3. दोनों icon URLs खोलकर देखें।
4. Chrome में DevTools → Application → Manifest और Service Workers में errors देखें (PC Chrome से भी कर सकते हैं)।
5. Android Chrome में site खोलें और browser के Install app / Add to Home screen विकल्प देखें। Install prompt हर स्थिति में तुरंत नहीं दिखता; Chrome के criteria और browser version के अनुसार विकल्प बदल सकता है।

## 8. एक ही repository में कई PWA के नियम

- हर PWA अलग folder में हो।
- हर PWA का manifest अलग हो।
- हर PWA का service worker अलग folder में हो और scope `./` हो।
- Cache name हर project के लिए unique रखें (उदाहरण `weather-tool-v1`, `stock-tool-v1`)।
- अलग ऐप पहचान के लिए `id` भी project-specific रखें, जैसे `./` (क्योंकि हर manifest का URL अलग folder में है)।
- एक ही folder में दो अलग PWA manifests रखकर एक ही page से उन्हें अलग-अलग installable app बनाना इस template का उद्देश्य नहीं है।

## सीमाएँ

यह starter installability की बुनियादी फाइलें देता है; यह अपने आप हर वेबसाइट को installable नहीं बना देता। HTTPS, valid manifest, accessible icons, correct paths और browser-specific install criteria जरूरी हैं। Service worker offline caching देता है, लेकिन इसे अपने app की वास्तविक files के अनुसार update करना होगा।
