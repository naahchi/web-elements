/*
 * Project-local service worker.
 * Change CACHE_VERSION whenever you make an update that must invalidate old cached files.
 * Keep this file and its scope inside the individual project folder.
 */
const CACHE_VERSION = "v1";
const CACHE_NAME = `my-pwa-project-${CACHE_VERSION}`;
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./style.css",
  "./app.js",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names.filter((name) => name !== CACHE_NAME).map((name) => caches.delete(name))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;

  // Network-first for page navigations, with cached app shell as offline fallback.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put("./", copy));
        return response;
      }).catch(() => caches.match("./"))
    );
    return;
  }

  // Cache-first for local project assets.
  event.respondWith(
    caches.match(request).then((cached) => cached || fetch(request))
  );
});
